## SuperGroup's languages (you can say !lang list):
| Commands | Usage | 
|:--------|:----------|:------------|
| <h4>[!#/]setlang `en` | Change launguage of supergroup to `enlish` when you are in a supergroup |
| <h4>[!#/]setlang `fa` | تغییر زبان سوپرگروه به `فارسی با دستورات انگلیسی` زمانیکه شما در سوپرگروه میباشید |
| <h4>[!#/]setlang `فا` | تغییر زبان سوپرگروه `فارسی با دستورات فارسی` زمانیکه شما در سوپرگروه میباشید |
## Chat's languages:
| Commands | Usage | 
|:--------|:----------|:------------|
| <h4>[!#/]setlang `en` | Change launguage of chat to `enlish` when you are in a chat |
| <h4>[!#/]setlang `fa` | تغییر زبان چت به `فارسی با دستورات انگلیسی` زمانیکه شما در چت میباشید |
| <h4>[!#/]setlang `فا` | تغییر زبان چت `فارسی با دستورات فارسی` زمانیکه شما در چت میباشید |

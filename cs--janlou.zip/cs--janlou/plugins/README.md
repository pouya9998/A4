# plugins

add plug folder plugins


go to data / nano config.lua 

add name plug and save ctrl x / y / enter .

./launch.sh = c9 
nohup ./launch.sh = ubuntu server 
